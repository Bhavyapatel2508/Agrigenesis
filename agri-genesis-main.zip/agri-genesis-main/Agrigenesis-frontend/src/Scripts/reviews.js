export const customerReviews = [
  {
    "name": "Raj Patel",
    "location": "Gujarat, India",
    "message": "The crop exchange feature is fantastic. I was able to trade surplus crops with a nearby farmer and get exactly what I needed. Highly recommend!"
},
{
    "name": "Aaryan Limbasiya",
    "location": "Gujarat, India",
    "message": "Thanks to the timely weather alerts and smart tools, I managed to save my crops from a severe storm. This platform is a must-have for any farmer."
}
];
